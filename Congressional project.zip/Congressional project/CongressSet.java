import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class CongressSet{
    public static void main(String[] args){
        showWindow();
    }
    public static void showWindow(){
        JFrame frame = new JFrame("Action Lizard");
        frame.setBounds(50,50,960,800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setVisible(true);
        
        JButton btn1 = new JButton("option 1");
        btn1.setBounds(280,100,400,160);
        frame.getContentPane().add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0){
                frame.setVisible(false);
                page1 p1 = new page1();
                p1.showWindow();
            }

        });

        JButton btn2 = new JButton("option 2");
        btn2.setBounds(280,310,400,160);
        frame.getContentPane().add(btn2);
        btn2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0){
                frame.setVisible(false);
                page2 p2 = new page2();
                p2.showWindow();
            }

        });

        JButton btn3 = new JButton("option 3");
        btn3.setBounds(280,520,400,160);
        frame.getContentPane().add(btn3);
        btn3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0){
                frame.setVisible(false);
                page3 p3 = new page3();
                p3.showWindow();
            }
        });
    }  
}


    

