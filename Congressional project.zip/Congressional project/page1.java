import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class page1 extends JFrame{
    public static void main(String[] args){
        showWindow();
    }

    

    public static void showWindow() {
        ImageIcon Logo = new ImageIcon("");
        JLabel Label = new JLabel();
        Label.setForeground(Color.GREEN);
        Label.setText("Founding fathers John Adams, Thomas Jefferson, and James Monroe died on July 4");
        Label.setVerticalAlignment(JLabel.CENTER);
        Label.setHorizontalAlignment(JLabel.CENTER);
        Label.setIcon(Logo);
        Label.setFont(new Font("Comic Sans MS",Font.BOLD,20));
        Label.setBackground(Color.RED);
        Label.setOpaque(true);
        Label.setVisible(true);

        JFrame frame = new JFrame("Action Lizard");
        frame.setBounds(50,50,960,800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(Label);

        /* 
        JButton btn1 = new JButton("back");
        btn1.setBounds(380,600,160,90);
        btn1.setLayout(null);
        frame.getContentPane().add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0){
                frame.setVisible(false);
                CongressSet CS = new CongressSet();
                CS.showWindow();
            }

        }); 
        */
    }  
}