import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Congrss extends JFrame{
    public static void main(String[] args){
        showWindow();
    }

    

    public static void showWindow() {
        ImageIcon Logo = new ImageIcon("Logoprime.png");
        JLabel Label = new JLabel();
        Label.setText("");
        Label.setVerticalAlignment(JLabel.TOP);
        Label.setHorizontalAlignment(JLabel.CENTER);
        Label.setIcon(Logo);
        
        
        JFrame frame = new JFrame("Action Lizard");
        frame.setBounds(50,50,960,800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(Label);

        JButton btn1 = new JButton("Start");
        btn1.setBounds(380,500,160,160);
        frame.getContentPane().add(btn1);
        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0){
                frame.setVisible(false);
                CongressSet CS = new CongressSet();
                CS.showWindow();
            }

        }); 

        Label.setBackground(Color.WHITE);
        Label.setOpaque(true);
    }  
}